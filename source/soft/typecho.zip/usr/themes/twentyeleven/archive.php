<?php $this->need('header.php'); ?>

<div id="primary">
			<div id="content" role="main">
			<?php if ($this->have()): ?>
			<?php while($this->next()): ?>
            	<article class="post hentry">
                	<header class="entry-header">
                    	<h1 class="entry-title"><a href="<?php $this->permalink() ?>" title="Permalink to <?php $this->title() ?>" rel="bookmark"><?php $this->title() ?></a></h1>
                        <div class="entry-meta">
				<span class="sep">Posted on </span><a href="<?php $this->permalink() ?>" title="<?php $this->date('g:i a'); ?>" rel="bookmark"><time class="entry-date" datetime="<?php $this->date('c'); ?>" pubdate=""><?php $this->date('d/m/Y'); ?></time></a><span class="by-author"> <span class="sep"> by </span> <span class="author vcard"><?php $this->author(); ?></span></span>			</div>
                    </header><!-- .entry-header -->
                    <div class="entry-content">
					<?php $this->content('Read More...'); ?>
                    </div><!-- .entry-content -->
                    <footer class="entry-meta">
                    	<span class="cat-links"><span class="entry-utility-prep entry-utility-prep-cat-links">Posted in</span> <?php $this->category(','); ?>			</span>
                    </footer><!-- #entry-meta -->
                </article>
            <?php endwhile; ?>
            <?php else: ?>
            <article class="post no-results not-found">
					<header class="entry-header">
						<h1 class="entry-title"><?php _e( 'Nothing Found', 'twentyeleven' ); ?></h1>
					</header><!-- .entry-header -->

					<div class="entry-content">
						<p><?php _e( 'Apologies, but no results were found for the requested archive. Perhaps searching will help find a related post.', 'twentyeleven' ); ?></p>
						
					</div><!-- .entry-content -->
			</article><!-- #post-0 -->
                
    	<?php endif; ?>
            <nav id="nav-below">
			<h3 class="assistive-text">Post navigation</h3>
			 <?php $this->pageNav(); ?>
			</nav>
			</div><!-- #content -->
		</div><!-- #primary -->
        
        
        
    
	<?php $this->need('sidebar.php'); ?>
	<?php $this->need('footer.php'); ?>
