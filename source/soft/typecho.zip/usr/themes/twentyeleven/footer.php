	</div><!-- #main -->

	<footer id="colophon" role="contentinfo">

			<div id="site-generator">
				<a href="<?php $this->options->siteurl(); ?>"><?php $this->options->title(); ?></a> <?php _e('is powered by'); ?> <a href="http://www.love4026.org" rel="nofollow">Ray</a><br /><a href="<?php $this->options->feedUrl(); ?>"><?php _e('Article'); ?> RSS</a> and <a href="<?php $this->options->commentsFeedUrl(); ?>"><?php _e('Comments'); ?> RSS</a>
			</div>
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php $this->footer(); ?>

</body>
</html>

