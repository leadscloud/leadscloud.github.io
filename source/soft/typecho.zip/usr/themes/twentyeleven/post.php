<?php $this->need('header.php'); ?>

<div id="primary">
			<div id="content" role="main">
					
<article class="post hentry">
	<header class="entry-header">
		<h1 class="entry-title"><?php $this->title() ?></h1>

				<div class="entry-meta">
			<span class="sep">Posted on </span><a href="<?php $this->permalink() ?>" title="<?php $this->date('g:i a'); ?>" rel="bookmark"><time class="entry-date" datetime="<?php $this->date('c'); ?>" pubdate=""><?php $this->date('d/m/Y'); ?></time></a><span class="by-author"> <span class="sep"> by </span> <span class="author vcard"><?php $this->author(); ?></span></span>		</div><!-- .entry-meta -->
			</header><!-- .entry-header -->

	<div class="entry-content">
		<?php $this->content(); ?>
			</div><!-- .entry-content -->

	<footer class="entry-meta">
        This entry was Posted in <?php $this->category(','); ?> and tagged <?php $this->tags(', ', true, 'none'); ?> by <?php $this->author(); ?>. Bookmark the <a href="<?php $this->permalink() ?>" title="Permalink to <?php $this->title() ?>" rel="bookmark">permalink</a>.
    </footer><!-- #entry-meta -->

</article><!-- #post-30269 -->

						<?php $this->need('comments.php'); ?><!-- #comments -->

				
			</div><!-- #content -->
		</div>
    
    
	<?php $this->need('sidebar.php'); ?>
	<?php $this->need('footer.php'); ?>
